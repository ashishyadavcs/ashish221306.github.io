const mongoose=require('mongoose');
const db_url=process.env.DB_URL;
mongoose.Promise=global.Promise;
mongoose.connect(db_url,{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useCreateIndex:true,
    useFindAndModify:true,
    useFindAndModify:false
}).then(()=>{
    console.log('database connected')
}).catch((error)=>{
    console.log(error)
})

module.exports=mongoose
