
  // Or with jQuery

  $(document).ready(function(){
    $('.sidenav').sidenav();
  });

  //dropdown
  $('.dropdown-trigger').dropdown()
  
  document.addEventListener("DOMContentLoaded", function(){
    $('.progress').delay(600).fadeOut('slow');
  });
  $(document).ready(function(){
    $('.modal').modal();
  });